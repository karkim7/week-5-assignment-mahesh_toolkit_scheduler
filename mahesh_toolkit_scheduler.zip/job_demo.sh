#!/bin/bash

# ---------------------------------------------------------------
# CS 450 - Stage 5: Job Control Demonstration Script
# 
# Demonstrates:
# - Background/foreground jobs
# - Process management (ps, kill)
# - Output redirection
# ---------------------------------------------------------------

LOG_FILE="job_control.log"

# Clear previous log
> "$LOG_FILE"

# Function: Simulate a long-running task (file organizer)
run_organizer() {
    echo "[$(date)] Starting file organizer in background..." | tee -a "$LOG_FILE"
    ./organize_files.sh test_files/ >> "$LOG_FILE" 2>&1 &
    ORGANIZER_PID=$!
    echo "  → Background PID: $ORGANIZER_PID" | tee -a "$LOG_FILE"
}

# Function: Simulate log analysis
run_log_analysis() {
    echo "[$(date)] Starting log analyzer in foreground..." | tee -a "$LOG_FILE"
    ./analyze_logs.sh test_files/Logs/access.log >> "$LOG_FILE" 2>&1
}

# Main demonstration
echo -e "\n\033[1;36m=== JOB CONTROL DEMONSTRATION ===\033[0m"

# 1. Start background job
run_organizer

# 2. Show job list
echo -e "\n\033[1;33mCurrent Jobs:\033[0m"
jobs -l | tee -a "$LOG_FILE"

# 3. Demonstrate process monitoring
echo -e "\n\033[1;33mProcess Status:\033[0m"
ps -p $ORGANIZER_PID -o pid,cmd | tee -a "$LOG_FILE"

# 4. Foreground/background switching
echo -e "\n\033[1;33mBringing job to foreground (wait 3 seconds)...\033[0m"
fg %1 > /dev/null 2>&1 &  # Simulate foreground (capture output silently)
sleep 3

# 5. Kill the process
echo -e "\n\033[1;33mTerminating organizer...\033[0m"
kill $ORGANIZER_PID 2>> "$LOG_FILE"
if [ $? -eq 0 ]; then
    echo "  → Successfully terminated PID $ORGANIZER_PID" | tee -a "$LOG_FILE"
else
    echo "  → Process already terminated" | tee -a "$LOG_FILE"
fi

# 6. Final process check
echo -e "\n\033[1;33mFinal Process Check:\033[0m"
ps -p $ORGANIZER_PID >/dev/null && echo "  → Process still running" || echo "  → Process ended" | tee -a "$LOG_FILE"

# 7. Run foreground task
echo -e "\n\033[1;36m=== FOREGROUND TASK DEMO ===\033[0m"
run_log_analysis

echo -e "\n\033[1;32mDemo complete! See full log at: $LOG_FILE\033[0m"
