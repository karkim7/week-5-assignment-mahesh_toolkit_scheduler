#!/bin/bash

# Stage 1: File Organizer
# Usage: ./organize_files.sh [directory]

target_dir=${1:-.}  # Default: current directory

echo "Organizing files in $target_dir by type..."

# Create subdirectories
mkdir -p "$target_dir/Text" "$target_dir/Logs" "$target_dir/Data" "$target_dir/Archives"

# Move files by type
find "$target_dir" -maxdepth 1 -type f -name "*.txt" -exec mv {} "$target_dir/Text/" \;
find "$target_dir" -maxdepth 1 -type f -name "*.log" -exec mv {} "$target_dir/Logs/" \;
find "$target_dir" -maxdepth 1 -type f -name "*.csv" -exec mv {} "$target_dir/Data/" \;
find "$target_dir" -maxdepth 1 -type f -name "*.tar.gz" -exec mv {} "$target_dir/Archives/" \;

echo " Done! Files organized into:"
ls -d "$target_dir"/*/