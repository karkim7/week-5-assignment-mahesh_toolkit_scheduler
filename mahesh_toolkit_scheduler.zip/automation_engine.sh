#!/bin/bash

# ----------------------------
# Existing Functions (Stage 4)
# ----------------------------

# Function to organize files
organize_files() {
    read -p "Enter directory to organize (leave blank for current dir): " dir
    ./organize_files.sh "${dir:-.}"
}

# Function to analyze logs
analyze_logs() {
    read -p "Enter logfile path (default: test_files/Logs/access.log): " logfile
    ./analyze_logs.sh "${logfile:-test_files/Logs/access.log}"
}

# Function to show disk usage
show_disk_usage() {
    echo -e "\n💽 Disk Usage:"
    df -h | awk '{print $1 "\t" $5 "\t" $6}' | column -t
}

# ----------------------------
# New Scheduling Functions (Stage 5)
# ----------------------------

# Run scheduled tasks (called by cron)
run_scheduled_task() {
    case $1 in
        "organize")
            echo "$(date): Starting file organization in $2" >> "$3"
            ./organize_files.sh "$2" >> "$3" 2>&1
            ;;
        "analyze")
            echo "$(date): Starting log analysis on $2" >> "$3"
            ./analyze_logs.sh "$2" >> "$3" 2>&1
            ;;
        *)
            echo "Unknown task: $1" >> "$3"
            exit 1
            ;;
    esac
    echo "$(date): Task completed" >> "$3"
}

# ----------------------------
# Execution Logic
# ----------------------------

# If arguments are provided, run in cron mode
if [[ $# -eq 3 ]]; then
    run_scheduled_task "$1" "$2" "$3"
    exit 0
fi

# ----------------------------
# Interactive Menu (Original UI)
# ----------------------------

while true; do
    clear
    echo "╔══════════════════════════════╗"
    echo "║    FILE MANAGEMENT MENU      ║"
    echo "╠══════════════════════════════╣"
    echo "║ 1. Organize files by type    ║"
    echo "║ 2. Analyze log files         ║"
    echo "║ 3. Check disk usage          ║"
    echo "║ 4. Schedule tasks (Stage 5)  ║"
    echo "║ 5. Exit                      ║"
    echo "╚══════════════════════════════╝"
    read -p "Choose an option (1-5): " choice

    case $choice in
        1) organize_files ;;
        2) analyze_logs ;;
        3) show_disk_usage ;;
        4) 
            echo -e "\n🕒 Scheduled Tasks:"
            echo "a) Weekly file organization (Sun 11:59 PM)"
            echo "b) Daily log analysis (2:30 AM)"
            echo -e "\nThese tasks are defined in crontab.txt"
            read -p "Press [Enter] to continue..."
            ;;
        5) echo "Exiting..."; exit 0 ;;
        *) echo "❌ Invalid option. Try again." ;;
    esac
    read -p "Press [Enter] to continue..."
done