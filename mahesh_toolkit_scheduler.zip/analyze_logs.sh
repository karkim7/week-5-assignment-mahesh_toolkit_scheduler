#!/bin/bash

# Stage 2: Log Analyzer
# Usage: ./analyze_logs.sh [logfile]

logfile=${1:-"test_files/access.log"}  # Default: access.log

echo "📊 Analyzing $logfile..."

# Count total lines, errors, and warnings
total_lines=$(wc -l < "$logfile")  
errors=$(grep -c "ERROR" "$logfile")  
warnings=$(grep -c "WARN" "$logfile")  

echo "Total lines: $total_lines"  
echo "Errors: $errors | Warnings: $warnings"  

# Show recent activity (last 3 lines)
echo -e "\n🔍 Recent Activity:"  
tail -n 3 "$logfile"  
